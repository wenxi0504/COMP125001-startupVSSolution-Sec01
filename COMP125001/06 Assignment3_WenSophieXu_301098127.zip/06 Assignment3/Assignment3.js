/*    JavaScript 6th Edition
 *    Assignment 3 
 *    Author:Wen Sophie Xu
 *    Date: 29th, June,2020

 *    Filename: Assignment3.js
 */
var list = document.getElementById("nav");
var a = document.createElement("a");
var li = document.createElement("li");
li.innerHTML = "Location";
a.appendChild(li);
list.appendChild(a);
a.href = "http://studentweb.cencol.ca/wxu63/";





